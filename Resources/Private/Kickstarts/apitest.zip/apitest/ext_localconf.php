<?php
defined('TYPO3') or die();

call_user_func(
	function( $extKey )
	{
	},
'apitest');
