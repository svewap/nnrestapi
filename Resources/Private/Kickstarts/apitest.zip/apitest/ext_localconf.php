<?php
defined('TYPO3_MODE') || die('Access denied.');

call_user_func(
	function( $extKey )
	{
		// Endpoint		
		\nn\rest::Endpoint()->register([
			'priority' 	=> '10',
			'slug' 		=> 'apitest',
			'namespace'	=> 'Nng\Apitest\Api'
		]);
	},
'apitest');
