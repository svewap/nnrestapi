<?php
defined('TYPO3_MODE') || die('Access denied.');

call_user_func(
	function( $extKey )
	{

		// Plugin registrieren
		\nn\t3::Registry()->configurePlugin( 'Nng\Apitest', 'main', 
            [\Nng\Apitest\Controller\MainController::class => 'index'],
            [\Nng\Apitest\Controller\MainController::class => 'index']
        );

		// Endpoint		
		\nn\rest::Endpoint()->register([
			'priority' 	=> '10',
			'slug' 		=> 'vue',
			'namespace'	=> 'Nng\Apitest\Api'
		]);
	},
'apitest');
