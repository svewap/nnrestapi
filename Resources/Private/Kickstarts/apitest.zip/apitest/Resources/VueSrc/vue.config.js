const path = require( 'path' );

const CKEditorWebpackPlugin = require( '@ckeditor/ckeditor5-dev-webpack-plugin' );
const { styles } = require( '@ckeditor/ckeditor5-dev-utils' );

// dynamically get the EXT-name for this extension, e.g. `apitest`
const typo3ExtensionName = __dirname.replace(/(.*)\/(.*)(\/Resources\/VueSrc)/i, '$2');

// make variable available as environment variable
process.env.VUE_APP_TYPO3_EXTNAME = typo3ExtensionName;

module.exports = {

	// target directory for the `dist` files
	outputDir: path.resolve(__dirname, "../Public/Vue/"),
	assetsDir: "",

	// when in context of typo3: use absolute path for assets
	publicPath: process.env.NODE_ENV === 'production'
	  ? `/typo3conf/ext/${typo3ExtensionName}/Resources/Public/Vue/`
	  : '/',
	
	
	transpileDependencies: [
        /ckeditor5-[^/\\]+[/\\]src[/\\].+\.js$/,
    ],

	configureWebpack: {
		plugins: [
            new CKEditorWebpackPlugin( {
                language: 'de',
                translationsOutputFile: /app/
            })
        ]
	},

	css: {
		loaderOptions: {
			sass: {
				sassOptions: {
					quietDeps: true
				},
				additionalData: `
					@import "@/assets/scss/_variables.scss";
					@import "@/assets/scss/_mixins.scss";
				`
			}
		}
	},

	chainWebpack: config => {

		// CKEditor
		const svgRule = config.module.rule( 'svg' );
		svgRule.exclude.add( path.join( __dirname, 'node_modules', '@ckeditor' ) );

		config.module
            .rule( 'cke-svg' )
            .test( /ckeditor5-[^/\\]+[/\\]theme[/\\]icons[/\\][^/\\]+\.svg$/ )
            .use( 'raw-loader' )
            .loader( 'raw-loader' );
		
		config.module
            .rule( 'cke-css' )
            .test( /ckeditor5-[^/\\]+[/\\].+\.css$/ )
            .use( 'postcss-loader' )
            .loader( 'postcss-loader' )
            .tap( () => {
                return styles.getPostCssConfig( {
                    themeImporter: {
                        themePath: require.resolve( '@ckeditor/ckeditor5-theme-lark' ),
                    },
                    minify: true
                });
            });

	}
}
