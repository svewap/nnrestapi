
import { createStore } from 'vuex'

export const store = createStore({
	state () {
		return {
			server: '',
			token: '',
		}
	},
	mutations: {

		// Load JWT (token) and server from localStorage
		initialize(state) {
			state.server = localStorage.getItem('uri')
			state.token = localStorage.getItem('token')
		},

		// Save `server` in store and localStorage
		server (state, uri) {
			state.server = uri
			localStorage.setItem('uri', uri)
		},

		// Save `token` in store and localStorage
		token (state, token) {
			state.token = token
			localStorage.setItem('token', token)
		}
	},
})
