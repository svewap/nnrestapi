<template>

	<n-config-provider :theme-overrides="{ common: { fontWeightStrong: '500' } }">
		<n-message-provider>
			<div class="container p-5">
				<router-view></router-view>
			</div>
		</n-message-provider>
	</n-config-provider>

</template>

<script>

export default {
	name: 'App',
	components: {
	},
	beforeCreate() { 
		this.$store.commit('initialize')
	},
	mounted() {
	}
}
</script>

<style lang="scss">
	
</style>
