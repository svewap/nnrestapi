<template>

	<h3>LOGIN</h3>
	
	<div class="form-group mb-3">
		<label class="form-label">URI to Rest-Api base-path</label>
		<input type="text" class="form-control" v-model="server" placeholder="https://www.yourserver.com/api/" />
	</div>
	<div class="mb-3">
		<label class="form-label">Username</label>
		<input type="text" class="form-control" v-model="username" />
	</div>
	<div class="mb-4">
		<label class="form-label">Password</label>
		<input type="password" class="form-control"  v-model="password" />
	</div>
	<div class="d-flex" :class="{loading:loading}">
		<p v-if="token">Token exists.</p>
		<button class="btn btn-primary ms-auto" @click="authenticate">{{ loading ? `Loading ...` : `Login` }}</button>
	</div>
	<div class="alert alert-danger mt-4" v-if="message">
		{{ message }}
	</div>
</template>

<script>

import axios from 'axios'
import { mapState } from 'vuex'

export default {
	props: [],
	data: () => ({
		server: '',
		username: '',
		password: '',
		message: '',
		loading: false
	}),
	computed: {
		...mapState(['token'])
	},
	mounted() {
		this.server = this.$store.state.server 
	},
	methods: {
		authenticate() {
			
			if (!this.server) {
				return this.message = 'Please enter a server!';
			}
			
			this.server = this.server.replace(/\/$/, '') + '/';
			this.$store.commit('server', this.server )
			this.loading = true;

			axios.post( `${this.server}auth`, { 
				username: this.username, 
				password: this.password 
			}).then(({ data }) => {

				// Successfully logged in. Save token in store / localStorage
				this.$store.commit('token', data.token )
				this.$router.push('edit')

			}).catch(({ response }) => {

				// 403 - Not authorized.
				this.message = `[${response.status}] ${response.data.error}`;

			}).finally(() => {

				// Hide spinner
				this.loading = false;
			});
		}
	}
}
</script>

<style scoped lang="scss">
	.loading {
		opacity: 0.4;
		pointer-events: none;
	}
</style>
