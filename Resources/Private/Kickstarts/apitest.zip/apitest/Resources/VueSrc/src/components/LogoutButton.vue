<template>
	<button @click="logout" class="btn btn-primary">Logout</button>
</template>

<script>

import axios from 'axios'
import { mapState } from 'vuex'

export default {
	computed: {
		...mapState(['server'])
	},
	methods: {
		logout() {
			axios.get( `${this.server}auth/logout` ).then(() => {
				this.$store.commit('token', '')
				this.$router.push('/')
			});
		}
	}
}
</script>

<style scoped>

</style>
