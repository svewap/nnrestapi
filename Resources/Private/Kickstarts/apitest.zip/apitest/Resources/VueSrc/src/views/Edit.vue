<template>

	<EditForm :color="color" @fucked="fuckedMe" />
	{{ color }}
</template>

<script>

import { defineComponent, ref, onMounted } from 'vue'
import EditForm from '@/components/EditForm'

export default defineComponent({

	components: {
		EditForm
	},

	setup () {

		const fuckedMe = () => {
			alert('Damn!');
		}

		const color = ref('#fff')

		setTimeout(() => {
			color.value = '#000'
			console.log( color.value );
		}, 1000);

		onMounted(() => {
		})

		return {
			color,
			fuckedMe
		}
	}
})
</script>