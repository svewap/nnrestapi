<template>
	<div class="RTE" :class="{error: maxCharsReached, unformatable:!formatable}">
		<!-- <component :is="placeholderTagName" class="placeholder" v-show="placeholderVisible">{{ placeholder }}</component> -->
		
		<!-- <ckeditor :tag-name="tagName" :editor="editor" class="ck-el" ref="editor" v-model="editorData" :config="editorConfig" @focus="onEditorFocus" @blur="onEditorBlur" @input="onEditorInput" @ready="onEditorMounted"></ckeditor> -->
		<ckeditor :editor="editor" v-model="editorData" :config="editorConfig"></ckeditor>
		
		<!-- <p v-if="maxChars > 0" class="maxchars">
			<span class="wordcount">{{ charCount }}</span>/{{ maxChars }}
		</p> -->

		{{ editorData }}
	</div>
</template>

<script>
	/**
	 * ### RTE Module
	 * A module for delivering a rich text editor.
	 *
	 * The RTE Module is based on the CKEditor Plugin. 
	 * The RTE can be used like this:
	 * ```
	 * <ModuleRTE @changed="onChange" v-model="text" maxChars="5" placeholder="String" :formatable="true" :trim="true" :toolbar="['bold', 'link']" />
	 * ```
	 * @requires ckeditor
	 * @class ModuleRTE
	**/
	
	import ClassicEditor from '@ckeditor/ckeditor5-editor-classic/src/classiceditor';

    import EssentialsPlugin from '@ckeditor/ckeditor5-essentials/src/essentials';
    import BoldPlugin from '@ckeditor/ckeditor5-basic-styles/src/bold';
	import List from '@ckeditor/ckeditor5-list/src/list';
    import ItalicPlugin from '@ckeditor/ckeditor5-basic-styles/src/italic';
    import LinkPlugin from '@ckeditor/ckeditor5-link/src/link';
    import ParagraphPlugin from '@ckeditor/ckeditor5-paragraph/src/paragraph';

	import CKEditor from '@ckeditor/ckeditor5-vue';

	export default {

		components: {
			ckeditor: CKEditor.component
		},

		/**
		 * Triggered once after the user has finished editing the text
		 * 
		 * 	<ModuleRTE @changed="..." />
		 * @event changed
		 * @param {Object} event 
		 */
		
		props: {
			value: String,
			label: String,

			/**
			 * Tagname to use for ckeditor-element
			 * 
			 * @property tagName
			 * @type Number
			 * @default div
			 */
			tagName: {
				type: String,
				default: 'div'
			},
			
			/**
			 * Maximum number of chars allowed before displaying an error
			 * 
			 * @property maxChars
			 * @type Number
			 * @default 0
			 */
			maxChars: {
				type: Number,
				default: 0
			},

			/**
			 * Placeholder text to show if textfield is empty
			 * 
			 * @property placeholder
			 * @type String
			 * @default ''
			 */
			placeholder: String,

			/**
			 * If toolbar should be displayed or not.
			 * Without the toolbar, no formatting is possible.
			 * Setting this to `false` will return text without HTML-formatting.
			 * 
			 * @property formatable
			 * @type Boolean
			 * @default true
			 */
			formatable: {
				type: Boolean,
				default: true
			},
			
			/**
			 * Remove whitespaces at beginning and end of the text
			 * 
			 * @property trim
			 * @type Boolean
			 * @default true
			 */
			trim: {
				type: Boolean,
				default: true
			},

			/**
			 * Which plugins to use in toolbar.
			 * 
			 * @property plugins
			 * @type Array
			 * @default []
			 */
			plugins: {
				type: Array,
				default() {
					return [
						EssentialsPlugin,
                        BoldPlugin,
                        List,
                        ItalicPlugin,
                        LinkPlugin,
						ParagraphPlugin
					];
				}
			},
			
			/**
			 * Which buttons to display in toolbar.
			 * 
			 * @property toolbar
			 * @type Array
			 * @default ['bold', 'link', 'bulletedList', 'numberedList','|']
			 */
			toolbar: {
				type: Array,
				default() {
					return ['bold', 'link', 'bulletedList', 'numberedList', '|'];
				}
			}
		},
		data: () => {
			return {
				focussed: false,
				editor: ClassicEditor,
				editorData: '<p>So nice...</p>',
				prevEditorData: '',
				charCount: 0,
				maxCharsReached: false,
				edited: false,
				local: ''
			}
		},

		computed: {

			placeholderVisible() {
				return !this.focussed && this.charCount == 0 && this.placeholder;
			},

			placeholderTagName() {
				if (this.tagName == 'div') return 'p';
				return this.tagName;
			},

			editorConfig() {
				var removePlugins = ['Heading'];
				return {
					removePlugins: removePlugins,
					plugins: this.plugins,
					toolbar: {
						items: this.formatable ? this.toolbar : [],
					}
				};
			},

			/**
			 * Return text with / without formatting, depending on the formatting property
			 * 
			 * @return {String} null
			 */
			returnValue() {
				var str = this.editorData;
				if (!str) str = '';
				if (!this.formatable) {
					str = str.replace(/<\/p><p>/ig,'<br>').replace(/<br>/ig, "\n").replace(/(<([^>]+)>)/ig, '');
				}
				if (this.trim) str = str.trim();
				return str;
			}
		},

		watch: {
			value(to) {
				this.focussed = true;
				this.$nextTick(() => {
					this.focussed = false;
					this.updateStatusElements();
				});
				if (to == this.returnValue) return;
				if (!to) to = '';
				this.editorData = this.formatable ? to : to.replace(/\n/ig, '<br>');
			}
		},
		
		methods: {

			/**
			 * Return the text without HTML-tags
			 * @method getPlainText
			 * @returns {String} null
			 */
			getPlainText() {
				if (!this.$refs.editor || !this.$refs.editor || !this.$refs.editor.$el) return '';
				var str = this.$refs.editor.$el.textContent.trim();
				return str;
			},

			/**
			 * Triggered when the editor is ready to go.
			 * @private
			 * @return {void} null
			 */
			onEditorMounted() {
				if (this.value) {
					this.editorData = this.value;
				}
				// hide ckeditor toolbar. todo: search for a better solution
				if (!this.formatable) {
					this.$refs.editor.$el.ckeditorInstance.ui.view.toolbar.element.parentNode.parentNode.classList.add('d-none');
				}
				this.updateStatusElements();
			},

			/**
			 * Warning if max chars is reached.
			 * 
			 * @private
			 * @return {void}
			 */
			updateStatusElements() {
				this.charCount = this.getPlainText().length;
				this.maxCharsReached = this.maxChars > 0 && this.maxChars <= this.charCount;
			},

			/**
			 * A function which is triggered if the RTE  Content is edited
			 * The method "onEditorInput" is used for calculating the current charCount and setting the related variables.
			 * @method onEditorInput
			 * @private
			 * @returns {void} null
			 */
			onEditorInput() {
				this.updateStatusElements();
				this.$emit('input', this.returnValue );
			},

			/**
			 * A function which is triggered if the RTE is active / in focus.
			 * The function "onEditorFocus" is used to adjust the style for the active Editor and calls "onEditorInput" for calculating the current charCount and setting the related variables.
			 * @method onEditorFocus
			 * @private
			 * @returns {void} null
			 */
			onEditorFocus() {
				this.focussed = true;
				this.prevEditorData = this.getPlainText();
				this.updateStatusElements();
			},

			/**
			 * A function which is triggered if the RTE is no longer active / in focus.
			 * The function  "onEditorBlur" is used to adjust the style for the non active Editor. it also emits the current value of the editor content.
			 * @method onEditorBlur
			 * @private
			 * @returns {void} null
			 */
			onEditorBlur() {
				this.focussed = false;
				if (!this.getPlainText().length) {
					this.updateStatusElements();
				}
				if (this.prevEditorData != this.getPlainText()) {
					this.$emit('changed', this.returnValue );
				}
			},
			
		}

	}

</script>

<style scoped lang="scss">
	.RTE {
		width: auto;
		margin: 10px auto;
		position: relative;

		&.error .maxchars {
			color: #ff0000;
			display: block;
		}

		.ck {
			background-color: #ffffff;
		}
		
		.maxchars {
			margin: 0 auto;
			padding: 5px;
			border-top: 1px solid lightgrey;
			background-color: rgba(255,255,255,0.5);
			font-size: 0.8rem;
		}

		.ck-el {
			border: 1px dashed #ddd;
		}

		.ck-el:hover,
		.ck-focused {
			border: 1px dashed #aaa !important;
			outline-width: 0;
		}
		
		.RTE.error .ck {
			border: 2px solid #ff0000;
		}

		.placeholder {
			color: #bbb;
			@include position( absolute, 0.55rem 0.5rem auto 1rem, 0 );
			margin: 0;
			padding: 0;
			pointer-events: none;
		}

		p.placeholder {
			top: 1rem;
		}

		h5 {
			font-weight: 300;
		}
	}
		
</style>
<style lang="scss">
	body {
		--ck-spacing-standard: 15px;
	} 
	.ck-el p {
		margin: 0 0.5rem 0.5rem 0;
	}
	.unformatable .ck.ck-editor__editable_inline {
		& > :first-child {
			margin-top: 8px;
		}
		& > :last-child {
			margin-bottom: 8px;
		}
	}
</style>