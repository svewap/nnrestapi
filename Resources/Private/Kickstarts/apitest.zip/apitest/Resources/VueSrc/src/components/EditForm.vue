<template>

		<UIRTE />


	<n-form :label-width="80" :model="formValue" :rules="rules" size="medium" ref="formRef">

		<n-grid :span="24" :x-gap="12">
			<n-form-item-gi :span="12" label="Artikel-Nr.">
				<n-input placeholder="z.B. FN013608" v-model:value="formValue.refnum" />
			</n-form-item-gi>
			<n-form-item-gi :span="12" label="Artikel-Name">
				<n-input placeholder="z.B. FN6130/01" v-model:value="formValue.title" />
			</n-form-item-gi>
		</n-grid>

		<n-form-item label="Titel">
			<n-input placeholder="z.B. Rufanlagen-Server FN6130/01" v-model:value="formValue.subtitle" />
		</n-form-item>
		
		<n-form-item label="Age" path="user.age">
			<n-input placeholder="Input Age" v-model:value="formValue.user.age" />
		</n-form-item>
		<n-form-item label="Phone" path="phone">
			<n-input placeholder="Phone Number" v-model:value="formValue.phone" />
		</n-form-item>
		<n-form-item>
			<n-button @click="handleValidateClick">Validate</n-button>
		</n-form-item>
	</n-form>

	<pre>
		{{ color }}
		{{ JSON.stringify(formValue, 0, 2) }}
	</pre>
</template>

<script>

import { defineComponent, ref, computed, onMounted } from 'vue'
import { useMessage } from 'naive-ui'
import UIRTE from '@/components/UI/UIRTE.vue'

export default defineComponent({
	
	components: {
		UIRTE
	},

	props: {
		color: {
			type: String,
			default: 'Nice!'
		},
	},
	
	emits: ['fucked'],

	setup ( props, context ) {
		
		const formRef = ref(null)
		const message = useMessage()
		const inc = ref(1)

		const formValue = ref({
			
			refnum: '',
			title: '',
			subtitle: '',
			user: {
				name: '',
				age: ''
			},
			phone: ''
		})

		onMounted(() => {
			setTimeout(() => {
				formValue.value.user.name = 'John'
			}, 2000);
		})

		const handleValidateClick = (e) => {
			e.preventDefault()
			formRef.value.validate((errors) => {
				if (!errors) {
					message.success('Valid')
				} else {
					console.log(errors)
					message.error('Invalid')
				}
			})
		}

		const handleInc = () => {
			inc.value++;
		}

		const test = computed(() => {
			console.log('YEP!');
			return inc;
		})

		const fuck = () => {
			console.log( inc.value );
			context.emit('fucked');
		}

		// expose to template
		return {
			formRef,
			formValue,
			inc,
			handleInc,
			handleValidateClick,
			test,
			fuck,
			/**
			 * Defines the validation-rules for the form.
			 * @see https://www.naiveui.com/en-US/light/components/form
			 * 
			 */
			rules: {},
		}
	}
})
</script>