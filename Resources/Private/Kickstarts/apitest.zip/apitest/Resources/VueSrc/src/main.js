import { createApp } from 'vue'
import App from './App.vue'

import router from '@/router'
import { store } from './store'

import 'vfonts/Roboto.css'
import 'vfonts/FiraCode.css'

// @see https://www.naiveui.com/

import {
    create,
    NButton,
    NInput,
    NConfigProvider,
    NSwitch,
    NAlert,
    NForm,
    NFormItem,
    NFormItemGi,
    NGrid,
    NGridItem,
    NSpace,
    NLayout,
    NLayoutHeader,
    NLayoutSider,
    NLayoutContent,
    NLayoutFooter,
    NMessageProvider,
    NRadioButton,
    NRadioGroup,
} from 'naive-ui'

const naive = create({
    components: [
        NButton,
        NInput,
        NConfigProvider,
        NSwitch,
        NAlert,
        NForm,
        NFormItem,
        NFormItemGi,
        NGrid,
        NMessageProvider,
        NGridItem,
        NSpace,
        NLayout,
        NLayoutHeader,
        NLayoutSider,
        NLayoutContent,
        NLayoutFooter,
        NRadioButton,
        NRadioGroup,    
    ]
})

import '@/assets/scss/app.scss'

createApp( App )
    .use( naive )
    .use( store )
    .use( router )
    .mount(`#app-${process.env.VUE_APP_TYPO3_EXTNAME}`);
