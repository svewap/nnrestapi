import {createRouter, createWebHashHistory} from "vue-router"

const routes = [
	{ 
		path: '/',
		name: 'login',
		component: () => import("@/views/Login") 
	},
	{ 
		path: '/edit',
		name: 'edit',
		component: () => import("@/views/Edit") 
	},
];

export default createRouter({
	history: createWebHashHistory(),
	routes,
})