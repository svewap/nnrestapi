<?php

namespace Nng\Apitest\Controller;

/**
 * Backend Module
 * 
 */
class MainController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController {

	/**
	 * @return void
	 */
	public function indexAction () {
		$site = $this->request->getAttribute('site', null);
		// $previousResult = $this->request->getAttribute('routing', null);
		// $pageArguments = $site->getRouter()->matchRequest($this->request, $previousResult);
		\nn\t3::debug( $site->getRouter() );
		\nn\t3::debug( $this->request->getAttribute('routing', null) );
		\nn\t3::debug( \nn\t3::FrontendUser()->get() );
	}

}
