<?php

namespace Nng\Apitest\Api;

use Nng\Apitest\Domain\Repository\EntryRepository;
use Nng\Apitest\Domain\Model\Entry as EntryModel;

use Nng\Nnrestapi\Annotations as Api;

class Entry extends \Nng\Nnrestapi\Api\AbstractApi 
{

	/**
	 * @var EntryRepository
	 */
	private $entryRepository = null;

	/**
	 * Constructor
	 * 
	 * @return void
	 */
	public function __construct() 
	{
		$this->entryRepository = \nn\t3::injectClass( EntryRepository::class );
		\nn\t3::Db()->ignoreEnableFields( $this->entryRepository );

	}

    /**
	 * @Api\Access("fe_users")
	 * @Api\Upload("apitest")
	 * 
	 * @param EntryModel $entry
	 * @param int $uid
	 * @return array
	 */
	public function putIndexAction( EntryModel $entry = null, int $uid = null )
	{
		if (!$uid) {
			return $this->response->notFound("No uid passed in URL. Send the request with `api/entry/{uid}`");
		}
		if (!$entry) {
			return $this->response->notFound("Example with uid [{$uid}] was not found.");
		}
	
		$this->entryRepository->update( $entry );
		\nn\t3::Db()->persistAll();

		$result = $this->entryRepository->findAll();
		return $result;
	}
  
	/**
	 * @Api\Access("fe_users")
	 * 
	 * @param EntryModel $entry
	 * @param int $uid
	 * @return array
	 */
	public function getIndexAction( EntryModel $entry = null, int $uid = null )
	{	
		if (!$uid) {
			return $this->response->notFound("No uid passed in URL. Send the request with `api/entry/{uid}`");
		}
		if (!$entry) {
			return $this->response->notFound("Example with uid [{$uid}] was not found.");
		}

		return $entry;
	}
	
	/**
	 * @Api\Access("fe_users")
	 * 
	 * @return array
	 */
	public function getAllAction()
	{	
		$result = $this->entryRepository->findAll();
		return $result;
	}
	
	/**
	 * @Api\Access("fe_users")
	 * @Api\Upload("apitest")
	 * @Api\Example("{'title':'Example', 'files':['UPLOAD:/file-0']}");
	 * 
	 * @param EntryModel $entry
	 * @return array
	 */
	public function postIndexAction( EntryModel $entry = null )
	{	
		$this->entryRepository->add( $entry );
		\nn\t3::Db()->persistAll();
		return $entry;
	}
	
	/**
	 * @Api\Access("fe_users")
	 * 
	 * @param EntryModel $entry
	 * @param int $uid
	 * @return array
	 */
	public function deleteIndexAction( EntryModel $entry = null, int $uid = null )
	{	
		if (!$entry) {
			return $this->response->notFound("Example with uid [{$uid}] was not found.");
		}
		
		$this->entryRepository->remove( $entry );
		\nn\t3::Db()->persistAll();

		$result = $this->entryRepository->findAll();
		return $result;
	}

}