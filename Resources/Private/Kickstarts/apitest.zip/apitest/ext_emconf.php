<?php

$EM_CONF[$_EXTKEY] = [
    'title' => 'VueJS / Rest-Api example',
    'description' => 'Example extension for EXT:nnrestapi with a VueJS frontend',
    'category' => 'frontend',
    'author' => 'yourcompany.de',
    'author_email' => 'your@email.de',
    'state' => 'stable',
    'internal' => '',
    'uploadfolder' => '0',
    'createDirs' => '',
    'clearCacheOnLoad' => 0,
    'version' => '0.1',
    'constraints' => [
        'depends' => [
            'typo3' => '9.5.0-11.9.99',
            'nnhelpers' => '1.4.0-0.0.0',
            'nnrestapi' => '1.0.0-0.0.0',
        ],
        'conflicts' => [],
        'suggests' => [],
    ],
];
