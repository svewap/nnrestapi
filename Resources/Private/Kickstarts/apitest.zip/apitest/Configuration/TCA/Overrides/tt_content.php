<?php
defined('TYPO3_MODE') or die();

\nn\t3::Registry()->plugin( 'Nng\Apitest', 'main', 'RestApi Vue Example', 'EXT:apitest/Resources/Public/Icons/Extension.svg' );
\nn\t3::Registry()->flexform( 'Nng\Apitest', 'main', 'FILE:EXT:apitest/Configuration/FlexForms/flexform.xml' );
