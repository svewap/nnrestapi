<?php

defined('TYPO3_MODE') || die('Access denied.');

call_user_func(
    function( $extKey )
    {		
		// add pageTSconfig
		\nn\t3::Settings()->addPageConfig('<INCLUDE_TYPOSCRIPT: source="FILE:EXT:apitest/Configuration/TypoScript/page.txt">');

		// register the icon
		\nn\t3::Registry()->icon('apitest-plugin', 'EXT:apitest/Resources/Public/Icons/Extension.svg');

	},
'apitest');