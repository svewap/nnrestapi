# Very Basic RestApi Extension

This example extension comes with a very simple ``Entry`` Domain Model and an Endpoint that
can create, read, update and delete Entries.

It is a great base to get started "from scratch" when developing your own TYPO3 RestApi.

## Installation

* In the Kickstarter: Enter a Vendor-Name and Extension-Name
* Hover over the package and click "Download". The browser will download the extension as a ZIP file.
* Install the extension in TYPO3 using the Extension Manager. If you are not in the composer mode, you can upload the ZIP-file directly in the backend.
* Include the static TypoScript templates in your site root
* Switch to the RestApi backend module to test the new endpoints
