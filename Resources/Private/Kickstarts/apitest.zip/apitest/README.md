# Very Basic RestApi Extension

This example extension comes with a very simple ``Entry`` Domain Model and an Endpoint that
can create, read, update and delete Entries.
